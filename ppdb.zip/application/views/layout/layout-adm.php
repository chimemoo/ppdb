<?php

    $this->load->view('layout/admin/header');
    $this->load->view('layout/admin/navigation');
    $this->load->view($content);
    $this->load->view('layout/admin/footer');

?>